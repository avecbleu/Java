package ver_dat_kundp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import interfacep.DB_zugriff;
import ver_dialog.Ver_kunde_update;

/*Aufruf aus  Ver_kundenanzeige
 * Parameter Kundenummer Bollean Variable  updp
 * Datenbankzugriff auf Kundenstamm und Adresstamm 
 * mit der ausgewählten  Kundennummer
 */




public class Ver_Kund_adr_ausw implements DB_zugriff {
	
    String  kundennummer  ;
	String name    ;
	String vorname ;
	String gebdat ;
    String	 strasse ; 
    String	 hausnr ;
    String	 plz  ;
    String	 ort   ;

    Boolean updb2;
    Boolean einfb;
	 public Ver_Kund_adr_ausw(String kundenr, int ausw){
		 //updb2=updb;
		 //einfb = verausw;  // Auswahl Versicherung 
		 Connection conn = null; 
		 try { 
			    System.out.println("* Treiber laden"); 
		      	    //Class.forName("org.gjt.mm.mysql.Driver").newInstance(); 
		        } 
		        catch (Exception e) { 
		            System.err.println("Treiber kann nicht geladen werden!!"); 
		            e.printStackTrace();
	            } 
		         
		        try { 
		    	    System.out.println("* Verbindung aufbauen"); 
		    	    String url = "jdbc:mysql://"+hostname+":"+port+"/"+dbname; 
		    	    conn = (Connection) DriverManager.getConnection(url, user, password); 
		    	    // ***** Verbindung
		    	    System.out.println("* Statement beginnen"); 
		            Statement stmt = (Statement) conn.createStatement(); 

		            System.out.println("* Abfrage beginnen"); 
			    String sqlCommand = 
			    		"SELECT  verk_kundnr, verk_name, verk_Vorname,verk_geburtstag, V_Strasse,"
			    		+"V_Hausnr,V_PLZ,V_Ort FROM ver_kundstamm"
			    	    + "	INNER JOIN ver_adresse ON ver_kundstamm.verk_kundnr = ver_adresse.V_Kundnr"
			    		//+ " Where verk_kundnr LIKE '%"+kundenr+"'" ;
			    		+ " Where verk_kundnr = '"+kundenr+"'" ;
			    		
			    System.out.println(sqlCommand);
			    ResultSet rs = ((java.sql.Statement) stmt).executeQuery(sqlCommand);
			    
			    //***Ausgabe
			    System.out.println("* Ergebnisse anzeigen"); 
			    while (rs.next()) { 
				 
				  kundennummer  = rs.getString(1); 
				  name    = rs.getString(2);
				  vorname = rs.getString(3);
				  gebdat = rs.getString(4);
			    	 strasse  = rs.getString(5);
			    	 hausnr  = rs.getString(6);
			    	 plz  = rs.getString(7);
			    	 ort   = rs.getString(8);
				//double gehalt = rs.getDouble(3);  hier weiter
				System.out.println( kundennummer+" "+name+" "+" "+vorname +" "+ gebdat+" "+strasse+ " " +hausnr
						     +" "  + plz +" " +ort ); 
			    } 
			    System.out.println("* Datenbank-Verbindung beenden"); 
	    	    conn.close(); 
	    	    // Aufruf GUIAnzeige  
	    	
	
	    	    switch(ausw) 
	    	    {
	    	       case 1:   // Update Einzelkunden 
	    	        Ver_kunde_update vku  = new Ver_kunde_update(kundennummer,name,vorname,gebdat,
	                     strasse,hausnr,plz,ort, sqlCommand);break;
	    	       case 2: break;
	    	    
	    	       case 3:  //Aufruf Anzeige Einzelkunde
	    	    	Ver_kund_anz vak  = new Ver_kund_anz(kundennummer,name,vorname,gebdat,
			                     strasse,hausnr,plz,ort); break;   
	    	      case 4:  
	    	    	Ver_vers_ins vvi = new Ver_vers_ins(kundennummer);
	    	    	break;
	    	    
		          case 5:  
	    	    	Ver_vers_ausw vva = new Ver_vers_ausw(kundennummer,name,vorname,gebdat, // Änderung
		                     strasse,hausnr,plz,ort); 
	    	    	break;
	    	    }
		       }  // Try Ende
	    	    
	            catch (SQLException sqle) { 
	                System.out.println("SQLException: " + sqle.getMessage()); 
	                System.out.println("SQLState: " + sqle.getSQLState()); 
	                System.out.println("VendorError: " + sqle.getErrorCode()); 
	                sqle.printStackTrace(); 
	            } 
		
	}
	



}

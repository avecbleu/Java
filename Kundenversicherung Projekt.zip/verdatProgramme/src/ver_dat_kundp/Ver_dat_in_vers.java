package ver_dat_kundp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/*Aufgerufen von Ver_vers_ins
 * inTabelle ver_versicherung wird Satz eingefügt  
 * 
 */

public class Ver_dat_in_vers implements interfacep.DB_zugriff {

	public Ver_dat_in_vers(String versnr, String vart, String vbez, String versbeginn, 
			                String versende, double vers_betrag, int kdnr) {
		
		Connection conn = null;

		try {
			System.out.println("* Treiber laden");
			// Class.forName("org.gjt.mm.mysql.Driver").newInstance();
		} catch (Exception e) {
			System.err.println("Treiber kann nicht geladen werden!!");
			e.printStackTrace();
		}

		try {
			System.out.println("* Verbindung aufbauen");
			String url = "jdbc:mysql://" + hostname + ":" + port + "/" + dbname;
			conn = DriverManager.getConnection(url, user, password);
			// ***** Verbindung  erst lesen  ver_kundstamm
			//lesen();
			System.out.println("* Statement beginnen");
			Statement stmt = (Statement) conn.createStatement();
			// *************hier SQL:Statments
			System.out.println("* Einfügen  beginnen");
			String sqlCommand = "Insert INTO ver_versicherung (ver_V_Key, Ver_Nr,"
					+ "r_ver_art, r_ver_bez,r_v_beginn,r_v_ende,r_betrag,r_kdnr,r_timestamp)" + 
					"VALUES(NULL  ," + "'" + versnr + "'" + ","
					+ "'" + vart + "'" + "," + "'" + vbez + "'" + ","+ "'" + versbeginn + "'" + ","+
					 "'" + versende + "'"+","+"'" + vers_betrag + "'" + ","+ 
					 "'" + kdnr + "'" + ","+"CURRENT_TIMESTAMP" + ")";
			   
			System.out.println(sqlCommand);
			((java.sql.Statement) stmt).executeUpdate(sqlCommand); // da nur geschrieben wird
											// executeUpdate

			// **beenden Eingabe
			System.out.println("* Statement beenden");
			//((Connection) stmt).close();
		      stmt.close();
			System.out.println("* Statement beginnen");
			stmt = (Statement) conn.createStatement();
			System.out.println("* Statement beenden");
			//((Connection) stmt).close();
			stmt.close();
			System.out.println("* Datenbank-Verbindung beenden");
			conn.close();
		} catch (SQLException sqle) {
			System.out.println("SQLException: " + sqle.getMessage());
			System.out.println("SQLState: " + sqle.getSQLState());
			System.out.println("VendorError: " + sqle.getErrorCode());
			sqle.printStackTrace();
		}


		
	}

}

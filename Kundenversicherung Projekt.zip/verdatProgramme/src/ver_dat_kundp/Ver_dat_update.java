package ver_dat_kundp;
 
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

//import interfaceP.DB_zugriff;

//Kunde  und Adresse (ver_kundstamm ) updaten von verkunde_update

public class Ver_dat_update implements interfacep.DB_zugriff {
String kundennummer,name, vorname, g_dat;

	public Ver_dat_update(String kundenr, String name2, String vorname2, String gebdb) {

	

		Connection conn = null;

		try {
			System.out.println("* Treiber laden");
			// Class.forName("org.gjt.mm.mysql.Driver").newInstance();
		} catch (Exception e) {
			System.err.println("Treiber kann nicht geladen werden!!");
			e.printStackTrace();
		}

		try {
			System.out.println("* Verbindung aufbauen");
			String url = "jdbc:mysql://" + hostname + ":" + port + "/" + dbname;
			conn = DriverManager.getConnection(url, user, password);
			// ***** Verbindung  erst lesen  ver_kundstamm
			//lesen();
			System.out.println("* Statement beginnen");
			Statement stmt = (Statement) conn.createStatement();
			// *************hier SQL:Statments
			System.out.println("* Einfügen  beginnen");

			

			System.out.println(kundenr + "  " + name2);
			
			String sqlCommand = "Update ver_kundstamm SET "+ " verk_name"+"="+ "'" +name2+"'"+"," + "verk_Vorname"+"="+"'"+vorname2+"'"+","
			               + "verk_geburtstag"+"="+"'"+gebdb+"'"+","+"verk_timestamp"+"=" + "NOW()" 
			               + " Where verk_kundnr = "+ kundenr+";";
			System.out.println(sqlCommand);
			((java.sql.Statement) stmt).executeUpdate(sqlCommand); // da nur geschrieben wird
											// executeUpdate

			// **beenden Eingabe
			System.out.println("* Statement beenden");
			//((Connection) stmt).close();
		      stmt.close();
			System.out.println("* Statement beginnen");
			stmt = (Statement) conn.createStatement();

			// ***Ausgabe
			System.out.println("* Ergebnisse anzeigen");
			System.out.println("* Abfrage beginnen");
			sqlCommand = "SELECT verk_kundnr, verk_name, verk_Vorname,verk_geburtstag FROM ver_kundstamm";
			ResultSet rs = ((java.sql.Statement) stmt).executeQuery(sqlCommand);
			// ***Ausgabe
			System.out.println("* Ergebnisse anzeigen");
			while (rs.next()) {

				kundennummer = rs.getString(1);
				name = rs.getString(2);
				vorname = rs.getString(3);
				g_dat = rs.getString(4);
				// double gehalt = rs.getDouble(3); hier weiter
				System.out.println(kundennummer + " " + name + " " + " " + vorname + " " + g_dat);

			}

			System.out.println("* Statement beenden");
			//((Connection) stmt).close();
			stmt.close();
			System.out.println("* Datenbank-Verbindung beenden");
			conn.close();
		} catch (SQLException sqle) {
			System.out.println("SQLException: " + sqle.getMessage());
			System.out.println("SQLState: " + sqle.getSQLState());
			System.out.println("VendorError: " + sqle.getErrorCode());
			sqle.printStackTrace();
		}

		// Ver_kund_anz vka = new Ver_kund_anz(kundennummer,name,vorname,g_dat);

	}// Konstruktor ende

	private void lesen() {
		// TODO Automatisch generierter Methodenstub
		
	}

}
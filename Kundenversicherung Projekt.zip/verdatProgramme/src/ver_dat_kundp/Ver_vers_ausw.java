package ver_dat_kundp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Ver_vers_ausw implements interfacep.DB_zugriff {
	ArrayList <String> lis_versi = new ArrayList <String>(); 

	public Ver_vers_ausw(String kundennummer, String name, String vorname, String gebdat, String strasse, String hausnr,
			String plz, String ort) {
		Connection conn = null;

		try {
			System.out.println("* Treiber laden");
			// Class.forName("org.gjt.mm.mysql.Driver").newInstance();
		} catch (Exception e) {
			System.err.println("Treiber kann nicht geladen werden!!");
			e.printStackTrace();
		}

		try {
			System.out.println("* Verbindung aufbauen");
			String url = "jdbc:mysql://" + hostname + ":" + port + "/" + dbname;
			conn = DriverManager.getConnection(url, user, password);
			// ***** Verbindung  erst lesen  ver_kundstamm
			//lesen();
			System.out.println("* Statement beginnen");
			Statement stmt = (Statement) conn.createStatement();
			
			
			// *************hier SQL:Statments
			String sqlCommand = 
		    		"SELECT  Ver_nr, r_ver_art,r_ver_bez, r_v_beginn,r_v_ende, r_betrag"
		    		+" FROM ver_versicherung"
		    	   	+ " Where r_kdnr = '"+kundennummer+"'" ;
			
			
			System.out.println(sqlCommand);
			ResultSet rs = ((java.sql.Statement) stmt).executeQuery(sqlCommand);
			//***Ausgabe
		    System.out.println("* Ergebnisse anzeigen"); 
		    while (rs.next()) { 
			 
			  lis_versi.add(rs.getString(1)); 
			  lis_versi.add(rs.getString(2));
			  lis_versi.add(rs.getString(3));
			  lis_versi.add(rs.getString(4));
		      lis_versi.add(rs.getString(5));
		      lis_versi.add(rs.getString(6));
		    	
		
			
		    } 						// 
		    System.out.println( lis_versi); 
			// **beenden Eingabe
			System.out.println("* Statement beenden");
			//((Connection) stmt).close();
		      stmt.close();
			System.out.println("* Statement beginnen");
			stmt = (Statement) conn.createStatement();
			System.out.println("* Statement beenden");
			//((Connection) stmt).close();
			stmt.close();
			System.out.println("* Datenbank-Verbindung beenden");
			conn.close();
			
			//Hier Programm aufrufen 
			ver_vers_anz2 vva = new ver_vers_anz2(kundennummer,name,vorname,gebdat,strasse,
				                            hausnr,plz,ort,lis_versi);
			
		} catch (SQLException sqle) {
			System.out.println("SQLException: " + sqle.getMessage());
			System.out.println("SQLState: " + sqle.getSQLState());
			System.out.println("VendorError: " + sqle.getErrorCode());
			sqle.printStackTrace();
		}
	}

}

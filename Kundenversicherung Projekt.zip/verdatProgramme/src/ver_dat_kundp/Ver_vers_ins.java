package ver_dat_kundp;

import static java.awt.GridBagConstraints.NORTH;

import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Ver_vers_ins extends JFrame implements ActionListener{
	
	JTextField ver_kundenr = new JTextField("",10);
	JTextField ver_nr = new JTextField("",15);
	JTextField ver_art = new JTextField("",10);
	JTextField ver_bez = new JTextField("",30);
	 
	JTextField ver_beginn = new JTextField("",10);
	JTextField ver_ende = new JTextField("",10);
	JTextField ver_betrag = new JTextField("",10);
	
	JButton knopf1 =new JButton(" ok");
	JButton knopf2 =new JButton(" Abbruch ");
	 Boolean fehler = true;
	 Font font = new Font(Font.DIALOG, Font.PLAIN, 16); // Font setzen
	//JDialog meinJDialog = new JDialog();
    int kdnr;
    String kdnrs;
	public Ver_vers_ins(String kundennummer) {
		kdnr= Integer.parseInt(kundennummer);
		kdnrs=kundennummer;
	
		
		// Titel wird gesetzt
			
			setTitle("Dialog  Eingaben Versicherung Ver_vers_ins");
		
		//setLayout(new BorderLayout());  //BorderLayout setzen
		// Das Programm soll  beendet werden.
			 fuellen(kundennummer);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			GridBagLayout gbLayout= new GridBagLayout();
			GridBagConstraints gbCons = new GridBagConstraints();
			setLayout(gbLayout);
		
		 // Hinzufügen  Komponenten, 
		JPanel panel = new JPanel();
		panel.setLayout(gbLayout);
		JLabel lkdnr = new JLabel("Kundenummer: ");
		JLabel lvnr =new JLabel("Vers_Nummer: ");
		JLabel lvart =new JLabel("Vers_Art");
		JLabel lvbez =new JLabel("Vers_Bez ");
		
		
		JLabel lvbeginn = new JLabel("Vers_Beginn TT.MM.JJJJ");
		JLabel lvende =new JLabel("Vers_Ende TT.MM.JJJJ ");
		JLabel lvbetrag =new JLabel("Vers_Betrag");
		
		
		// Festlegung horizontal oder vertikal 
	    
		
		 gbCons.anchor = NORTH;	
		 gbCons.fill = GridBagConstraints.HORIZONTAL;
		 gbCons.weightx = .2;
	     gbCons.gridx =0;
	     gbCons.gridy =0;
	     gbCons.insets = new Insets(10, 0, 15, 0);// Abstand Zeilen top,left,bottom,right
		
		//**Label Ende
	     //FONT setzen
	     lkdnr.setFont(font);
		add(lkdnr,gbCons);
		//Kcombo.addActionListener(klist);
		
	     gbCons.gridx =1;
	    // gbCons.gridy =0;		 
	   //FONT setzen
	     ver_kundenr.setFont(font);
	     ver_kundenr.setColumns(10);
		add(ver_kundenr,gbCons);
		
		//********Kundennummer Ende
		
		//Versicherungsnummer
		gbCons.fill = GridBagConstraints.HORIZONTAL;
		gbCons.gridy =1;
		gbCons.gridx =0;
		//FONT setzen
	    lvnr.setFont(font);
		add(lvnr,gbCons);
		//***Label Versicherungsnummer Ende 
		
		gbCons.weightx = .4;
		gbCons.gridx =1;
		// Font setzen
		ver_nr=mfont(ver_nr);
		add(ver_nr,gbCons);
		//****Versicherungsnummer Ende 
		//Versicherungsart
		gbCons.gridy =3;
		gbCons.gridx =0;
		// Font setzen
		lvart=mfontl(lvart);
		add(lvart,gbCons);
		//**Label VersicherungsartEnde
		gbCons.weightx = .4;
		gbCons.gridx =1;
		// Font setzen
			ver_art=mfont(ver_art);
		add(ver_art,gbCons);
		//****** Versicherungsart Ende
		//Bezeichnung
		gbCons.gridy =4;
		gbCons.gridx =0;
		// Font setzen
			lvbez=mfontl(lvbez);
		add(lvbez,gbCons);
		//***Label Bezeichnung Ende
		gbCons.weightx = .4;
		gbCons.gridx =1;
		// Font setzen
		ver_bez=mfont(ver_bez);
		add(ver_bez,gbCons);
		//****Bezeichnung Ende
		 gbCons.insets = new Insets(30, 0, 15, 0);// Abstand Zeilen top,left,bottom,right
			
		
		//Vesicherungsbeginn
		gbCons.weightx = .2;
	    gbCons.gridx =0;
	    gbCons.gridy =6;		 
	 // Font setzen
	 	lvbeginn=mfontl(lvbeginn);
		add(lvbeginn,gbCons);
		gbCons.gridx =1;
		// Font setzen
		ver_beginn=mfont(ver_beginn);
		add(ver_beginn,gbCons);
		//********Versicherungsbeginn Ende
			//Versicherungsende
		gbCons.weightx = .2;
	    gbCons.gridx =0;
	    gbCons.gridy =7;		 
	 // Font setzen
	 	lvende=mfontl(lvende);
		add(lvende,gbCons);
			gbCons.weightx = .2;
			gbCons.gridx =1;
			gbCons.gridy =7;
			// Font setzen 
			ver_ende=mfont(ver_ende);
			add(ver_ende,gbCons);
			//****Versicherungsende  Ende 
			 gbCons.insets = new Insets(10, 0, 15, 0);// Abstand Zeilen top,left,bottom,right
				
			//Versicherungsbetrag 
			gbCons.gridy =8;
			gbCons.gridx =0;
			// Font setzen
			lvbetrag=mfontl(lvbetrag);
			add(lvbetrag,gbCons);
			//**Label Versicherungsbetrag Ende
			gbCons.weightx = .4;
			gbCons.gridx =1;
			// Font setzen
			ver_betrag=mfont(ver_betrag);
			add(ver_betrag,gbCons);
			//****** Versicherungsbetrag   Ende
			//Ort
			gbCons.gridy =8;
			gbCons.gridx =2;
			
		
	    
		
		//Zuweisung Button 
		gbCons.fill = GridBagConstraints.VERTICAL;
		//gbCons.gridheight =2;
		//gbCons.weightx = 0.5;
		gbCons.gridy =20;
		gbCons.gridx =0;
		
		
		//********Button
		add(knopf1,gbCons);
		//gbCons.fill = GridBagConstraints.BOTH;
		gbCons.gridheight =2;
		gbCons.gridy =20;
		gbCons.gridx =1;
		add(knopf2,gbCons);
		//****Ende Knöpfe
		knopf1.addActionListener(this);
		knopf2.addActionListener(this);
		
		setSize(800, 500);
		//pack();
		
	    this.add(panel);
	    pack();
			setVisible(true);
		}
              //Kundennummer übergeben
		private void fuellen(String kundennummer) {
		ver_kundenr.setText(kundennummer);
		ver_kundenr.setEditable(false);
		
	}

		@Override
		public void actionPerformed(ActionEvent e) {
			
			if(e.getSource() == this.knopf1){  
	           
	           String versnr = this.ver_nr.getText();  //Prüfen versicherungsnummer
	           pruefi(versnr);
	          if(fehler) {
	        	   
	           
	        	   
	   		   String vart  = this.ver_art.getText();    //Versicherungsart
	   		   pr_buchst(vart);
	   		   String vbez  = this.ver_bez.getText();    //übernehmen Versicherungsbezeichnung
	   		   pr_buchst(vbez);
	   		    //String vbeginn   = this.ver_beginn.getText();    //übernehmen Begin
	   		  System.out.println("Knopf1 an "+ versnr+ " Versart "+ ver_art);
	   		//**********Leerzeichen entfernen 
	   		  versnr  = versnr.trim(); 
	   		  vart  = vart.trim();  
	   		  vbez  = vbez.trim();
	   		  // vbeginn  = vbeginn.trim(); 
	   		System.out.println("Knopf1 an "+ versnr+ " Verbez "+ ver_bez);
	   		
	   		
	     	 String verbeginn = this.ver_beginn.getText();  //Übernehmen Versicherungsbeginn
	     	 verbeginn = verbeginn.trim();
	     	 pruefz(verbeginn);
			   String verende  = this.ver_ende.getText();    //Übernehmen Versicherungsende
			   verende= verende.trim();
			   String verbetrag  = this.ver_betrag.getText();   //Übernehmen Versicherungsbetrag
			   verbetrag= verbetrag.replace(",", ".");
			   System.out.println(verbetrag);
			   pruefz(verbetrag);
			   //String ort   = this.v_ort.getText();    //ort
			   
	   		  //meinJDialog.dispose();
	   		   dispose();
	   		 //Aufruf Programm    In ver_versicherung schreiben 
	   		   String versbeginn=datumumw(verbeginn);
	   		   System.out.println("versbeginn "+versbeginn);
	   		   String versende = datumumw(verende);
	   		   //Umwandeln in double
	   		   double vers_betrag= Double.parseDouble(verbetrag);
	   		   if(fehler) {
	   	      	Ver_dat_in_vers vdiv = new Ver_dat_in_vers(versnr, vart, vbez,versbeginn,
	   		   	                                    versende,vers_betrag,kdnr);
	   		   }	
	   	   	 //Aufruf Programm    In ver_adresse schreiben 
	   	   //		Ver_insert_adressstamm vdau = new Ver_insert_adressstamm(strasse,hausnr,plz,ort,lkz,kundenr);   
	        }
			else if (e.getSource() == this.knopf2){
				System.out.println("Knopf2 an" );
				System.exit(0);
			}
		}     // if ende
		}
		//Datum von TT.MM.JJJJ in JJJJ-MM-TT umwandeln 
		private String datumumw(String verdat) {
			String tt;
			String mm;
			String jj;
			String datum;
			tt= verdat.substring(0,2);
			mm= verdat.substring(3,5);
			jj =verdat.substring(6);
			datum = jj+"-"+mm+"-"+tt;
			return datum;
		}
		//Prüfen auf Zahlen 
		private void pruefz(String verbetrag) {
			String onlyRegex="[0-9.]*";
			if(verbetrag.matches(onlyRegex)) {
				System.out.println("richtig  Zahlen und .");
				//fehler = true;
			}
			else {
				System.out.println("Bitte bei Betrag nur zahlen eingeben");
				//Ver_kunde verk = new Ver_kunde();
				fehler= false;
			}	
			
			
		}
		//Überprüfen  feld name  
		 private void pr_buchst(String name) {
			
			 String onlyRegex="[a-zA-ZßöäüÄÖÜ-]*";
			 if(name.matches(onlyRegex)) {
					System.out.println("Richtig nur Buchstaben");
					//fehler = true;
				}
				else {
				JOptionPane.showMessageDialog(null, "Bitte  Buchstaben oder - eingeben!");
					System.out.println("Bitte  Buchstaben  oder - eingeben!");
					//Ver_kunde verk = new Ver_kunde();
					fehler= false;
					//Ver_vers_ins vvi = new Ver_vers_ins (kdnrs);
				}	
		}

		// Font setzten  Label 
			private JLabel mfontl(JLabel label1) {
				label1.setFont(font);
				return label1;
			}

			//********Font setzen  TextFeld
		       private JTextField mfont(JTextField feld) {
		    	 //FONT setzen
		    	     feld.setFont(font);
				return feld;
			}
		private void pruefi(String kundenr) {
			String onlyRegex="[0-9]*";
			if(kundenr.matches(onlyRegex)) {
				System.out.println("richtig Nur Zahlen");
				//fehler = true;
			}
			else {
				System.out.println("Bitte bei Kundenummer nur zahlen eingeben");
				//Ver_kunde verk = new Ver_kunde();
				fehler= false;
			}	
		}	
		
		
	}

//}

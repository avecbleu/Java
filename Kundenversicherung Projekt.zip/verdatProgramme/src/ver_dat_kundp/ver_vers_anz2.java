package ver_dat_kundp;

import static java.awt.GridBagConstraints.PAGE_START;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class ver_vers_anz2 extends JFrame{
	private int top, left, bottom, right;
    private final Insets insetsTop = new Insets(top = 5, left = 2, bottom = 15, right = 0);
  String gebdats,jj,mm, tt;    

	public ver_vers_anz2(String kundennummer, String name, String vorname, String gebdat, String strasse, String hausnr,
			String plz, String ort, ArrayList<String> lis_versi) {
		
		this.setTitle("Anzeigen Kundenstamm mit Versicherungen ververs_anz");
		 setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        GridBagLayout gbLayout = new GridBagLayout();
	        GridBagConstraints gbConstraints = new GridBagConstraints();
	        setLayout(gbLayout);
	        //Anzeig Überschrift
	        gbConstraints.fill = GridBagConstraints.HORIZONTAL;
	        
	        //********Anzeigen Label Name
	        gbConstraints.weightx = 0;
	        gbConstraints.weighty = 0;
	        gbConstraints.anchor = PAGE_START;
	        gbConstraints.gridx = 0;
	        gbConstraints.gridy = 0;
	        gbConstraints.insets = insetsTop;	       
	        JLabel texthaed = new JLabel("Ausgabe Kundenstamm mit Versicherungsdaten " );
	        add(texthaed,gbConstraints);
	        //Kundnnummer 
	        gbConstraints.fill = GridBagConstraints.HORIZONTAL;
	        gbConstraints.weightx = 0;
	        gbConstraints.weighty =0; 
	       
	        gbConstraints.gridx = 0;
	        gbConstraints.gridy = 1;
	       gbConstraints.insets = insetsTop;	       
	        JLabel textkdnr = new JLabel("Kundennummer:" );
	        add(textkdnr,gbConstraints);
	        //*****Anzeigen Kundennummer aus Datenbank
	        gbConstraints.weightx = 1;
	        //gbConstraints.weighty = 1;
	        gbConstraints.gridx = 1;
	        gbConstraints.gridy = 1;
	        JLabel lkdnr = new JLabel();
	        lkdnr.setText(kundennummer);      
	        add(lkdnr,gbConstraints);
	        
	      gbConstraints.fill = GridBagConstraints.HORIZONTAL;
	        gbConstraints.weightx = 0;
	        gbConstraints.weighty =0; 
	       // gbConstraints.anchor = PAGE_START;
	        gbConstraints.gridx = 2;
	        gbConstraints.gridy = 1;
	       gbConstraints.insets = insetsTop;	       
	        JLabel textName = new JLabel("Name:" );
	        add(textName,gbConstraints);
	        //*****Anzeigen Name aus Datenbank
	        gbConstraints.weightx = 1;
	        //gbConstraints.weighty = 1;
	        gbConstraints.gridx = 3;
	        gbConstraints.gridy = 1;
	        JLabel lName = new JLabel();
	        lName.setText(name);      
	        add(lName,gbConstraints);
	      //*****Anzeigen Label Vorname
	        gbConstraints.weightx = .5;
	        //gbConstraints.weighty = 0.5;
	        gbConstraints.gridx = 0;
	        gbConstraints.gridy = 2;
	        JLabel textvName = new JLabel("Vorname:" );
	        add(textvName,gbConstraints);
	        //**********Anzeigen Vorname aus Datenbank
	        gbConstraints.weightx = 1;
	       // gbConstraints.weighty = 1;
	        gbConstraints.gridx = 1;	        
	        JLabel lvName = new JLabel();
	        lvName.setText(vorname);      
	        add(lvName,gbConstraints);
	     //*****Anzeigen Label Gebursdatum
	        gbConstraints.weightx = .5;
	        gbConstraints.gridx = 2;
	        gbConstraints.gridy = 2;
	        JLabel textvgebd = new JLabel("Geb_Dat:" );
	        add(textvgebd,gbConstraints);
	       //**********Anzeigen Geb_datum aus Datenbank
	        gbConstraints.weightx = 1;
	       // gbConstraints.weighty = 1;
	        gbConstraints.gridx = 3;	        
	        JLabel lgebdat = new JLabel();
	        lgebdat.setText(gebdat);      
	        add(lgebdat,gbConstraints);
	         //*******Anzeigen Label Strasse
	        gbConstraints.weightx = .5;
	        gbConstraints.gridx = 0;
	        gbConstraints.gridy = 3;
	        JLabel textstr = new JLabel("Straße:" );
	        add(textstr,gbConstraints);
	      //*******Anzeigen Label StraßeDatenbank
	        gbConstraints.weightx = 1;
	        gbConstraints.gridx = 1;
	        JLabel lstrasse = new JLabel();
	        lstrasse.setText(strasse);
	        add(lstrasse,gbConstraints);
	      //*******Anzeigen Label Hausnummer
	        gbConstraints.weightx = .5;
	        gbConstraints.gridx = 2;
	        gbConstraints.gridy = 3;
	        JLabel texthsr = new JLabel("Hausnummer:" );
	        add(texthsr,gbConstraints);
	      //*******Anzeigen Label Hausnummer Datenbank
	        gbConstraints.weightx = 1;
	        gbConstraints.gridx = 3;
	        JLabel lhsr = new JLabel();
	        lhsr.setText(hausnr);
	        add(lhsr,gbConstraints);
	        //*******Anzeigen Label Postleitzahl
	        gbConstraints.weightx = .5;
	        gbConstraints.gridx = 0;
	        gbConstraints.gridy = 4;
	        JLabel textplz = new JLabel("Postleitzahl:" );
	        add(textplz,gbConstraints);
	      //*******Anzeigen Label Postleitzahl Datenbank
	        gbConstraints.weightx = 1;
	        gbConstraints.gridx = 1;
	        JLabel lplz = new JLabel();
	        lplz.setText(plz);
	        add(lplz,gbConstraints);
	        //*******Anzeigen Label Ort
	        gbConstraints.weightx = .5;
	        gbConstraints.gridx = 2;
	        gbConstraints.gridy = 4;
	        JLabel textort = new JLabel("Ort:" );
	        add(textort,gbConstraints);
	      //*******Anzeigen Feld Ort Datenbank
	        gbConstraints.weightx = 1;
	        gbConstraints.gridx = 3;
	        JLabel lort = new JLabel();
	        lort.setText(ort);
	        add(lort,gbConstraints);
	      
	        //*************Versicherungsdaten 
	        int za=0;   // Zähler lis_versi
	        int zy=7;  // Zähler für Ausgabe in Zeile 
	        int liz= lis_versi.size();
	        
	        int zeilen= liz/6; //wie viele Zeilen zusätzlich  
	        
	        System.out.println (" Zähler lis "+ liz);
	        do {
	      //*******Anzeigen Versicherung 
	        gbConstraints.weightx = 1;
	        gbConstraints.gridx = 3;
	        gbConstraints.gridy = 5;
	        JLabel lanzeige = new JLabel("***V e r s i c h e r u n g s d a t e n***");
	        //lort.setText(lanzeige);
	        add(lanzeige,gbConstraints);
	        //  Versicherungsnummer  
	        gbConstraints.weightx = .5;
	        gbConstraints.gridx = 0;
	        gbConstraints.gridy = 6;
	        JLabel textvernr = new JLabel("Ver-Nr:" );
	         add(textvernr,gbConstraints);
	        //*******Anzeigen Feld Ver-Nr Datenbank
	         
	         if(zeilen > 1 && za >5) {
	        	 zy++;
	         }
	        gbConstraints.weightx = 1;
	        gbConstraints.gridx = 0;
	        gbConstraints.gridy = zy;
	        JLabel ltvernsnr = new JLabel();
	        ltvernsnr.setText(lis_versi.get(za));
	        add(ltvernsnr,gbConstraints);
	        //** Anzeige Versicherungsart
	        gbConstraints.weightx = .5;
	        gbConstraints.gridx = 2;
	        gbConstraints.gridy = 6;
	         JLabel textverart = new JLabel("Ver-Art:" );
	         add(textverart,gbConstraints);
	        //*******Anzeigen Feld Ver-Nr Datenbank
	         za++;
	         
	        gbConstraints.weightx = 1;
	        gbConstraints.gridx = 2;
	        gbConstraints.gridy = zy;
	        JLabel ltverart = new JLabel();
	        ltverart.setText(lis_versi.get(za));
	        add(ltverart,gbConstraints);
	        //** Anzeige Versicherungsbezeichnung
	        gbConstraints.weightx = .5;
	        gbConstraints.gridx = 4;
	        gbConstraints.gridy = 6;
	         JLabel textverbez = new JLabel("Ver-Bez:" );
	         add(textverbez,gbConstraints);
	         //*******Anzeigen Feld Ver-Bez Datenbank
	         za++;
	         
		        gbConstraints.weightx = 1;
		        gbConstraints.gridx = 4;
		        gbConstraints.gridy = zy;
		        JLabel ltverbez = new JLabel();
		        ltverbez.setText(lis_versi.get(za));
		        add(ltverbez,gbConstraints);
		        //** Anzeige Versicherungsbeginn
		        gbConstraints.weightx = .5;
		        gbConstraints.gridx = 6;
		        gbConstraints.gridy = 6;
		         JLabel textverbeg = new JLabel("Ver-Beginn:" );
		         add(textverbeg,gbConstraints);
		         //*******Anzeigen Feld Ver-Beginn aus Datenbank
		         za++;
		        
			        gbConstraints.weightx = 1;
			        gbConstraints.gridx = 6;
			        gbConstraints.gridy = zy;
			        JLabel ltverbeg = new JLabel();
			        ltverbeg.setText(lis_versi.get(za));
			        add(ltverbeg,gbConstraints);
			        //** Anzeige VersicherungsEnde
			        gbConstraints.weightx = .5;
			        gbConstraints.gridx = 8;
			        gbConstraints.gridy = 6;
			         JLabel textverend = new JLabel("Ver-Ende:" );
			         add(textverend,gbConstraints);
			         //*******Anzeigen Feld Ver-Ende aus Datenbank
			         za++;
			       //  if(zeilen > 1 && za >5) {
			        //	 zy++;
			       //  }
				        gbConstraints.weightx = 1;
				        gbConstraints.gridx = 8;
				        gbConstraints.gridy = zy;
				        JLabel ltverend = new JLabel();
				        ltverend.setText(lis_versi.get(za));
				        add(ltverend,gbConstraints);
				      //** Anzeige Versicherungsbetrag
				        gbConstraints.weightx = .5;
				        gbConstraints.gridx = 9;
				        gbConstraints.gridy = 6;
				         JLabel textverbet = new JLabel("Ver-Betrag:" );
				         add(textverbet,gbConstraints);
				         //*******Anzeigen Feld Ver-Ende aus Datenbank
				         za++;
				         
					        gbConstraints.weightx = 1;
					        gbConstraints.gridx = 9;
					        gbConstraints.gridy = zy;
					        JLabel ltverbet = new JLabel();
					        ltverbet.setText(lis_versi.get(za).replace(".", ","));
					        add(ltverbet,gbConstraints);
					        za++;
	        }      
					  while (za < lis_versi.size()-1);
	         
	        // GUI Aufrufen 
	        setSize(1000, 500);
	       // pack();
	        setVisible(true);
	}

		
}

//}

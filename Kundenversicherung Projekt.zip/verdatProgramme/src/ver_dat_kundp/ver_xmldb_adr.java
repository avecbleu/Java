package ver_dat_kundp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import interfacep.DB_zugriff;
/*
*Aus  ver_xml_auslesen  ArrayList lis_Adresse  übernehmen 
*/
public class ver_xmldb_adr implements DB_zugriff {

	ArrayList <String> lis_adressi = new ArrayList <String>(); 
	
	public ver_xmldb_adr(ArrayList<String> lis_adresse) {
		 lis_adressi=lis_adresse;
		 Connection conn = null;

			try {
				System.out.println("* Treiber laden");
				
			} catch (Exception e) {
				System.err.println("Treiber kann nicht geladen werden!!");
				e.printStackTrace();
			}
	                  
	                  
			try {
				System.out.println("* Verbindung aufbauen");
				String url = "jdbc:mysql://" + hostname + ":" + port + "/" + dbname;
				conn = DriverManager.getConnection(url, user, password);
				// ***** Verbindung
				System.out.println("* Statement beginnen");
				Statement stmt = (Statement) conn.createStatement();
				System.out.println("* Einfügen  beginnen");
				
				//Schleife zum Auslesen lis_adressi aus 
				 for (int z=0; z <lis_adressi.size();z++) {
					 String sqlCommand = "Insert INTO ver_adresse (V_Strasse, V_Hausnr,"
								+ "V_PLZ, V_Ort,V_LKZ,V_Kundnr,V_timestamp)" 
								+ "VALUES("+ "'" + lis_adressi.get(z) + "'" +"," + "'" 
								+ lis_adressi.get(++z) + "'" + ","	+ "'" + lis_adressi.get(++z) 
								+ "'" + "," + "'" + lis_adressi.get(++z)   + "'" + ","
								+ "'" + lis_adressi.get(++z) + "'" + "," + "'" + lis_adressi.get(++z) + "'" + ","
								+"NOW()" + ")";
					 System.out.println(sqlCommand);
					((java.sql.Statement) stmt).executeUpdate(sqlCommand); // da nur geschrieben wird
													              	// executeUpdate
										 
				 } //for Ende
				// **beenden Eingabe
					System.out.println("* Statement beenden");
					//((Connection) stmt).close();
				      stmt.close();
			} catch (SQLException sqle) {
				System.out.println("SQLException: " + sqle.getMessage());
				System.out.println("SQLState: " + sqle.getSQLState());
				System.out.println("VendorError: " + sqle.getErrorCode());
				sqle.printStackTrace();
			}	 
	}

}

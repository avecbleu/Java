package ver_dat_kundp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
/*
 *Aus  ver_xml_auslesen  ArrayList lis_kunde übernehmen 
 */
import interfacep.DB_zugriff;

public class ver_xmldb_ku implements DB_zugriff {
     
	 ArrayList <String> lis_kundi = new ArrayList <String>(); 
	 
	public ver_xmldb_ku(ArrayList<String> lis_kunde) {
		lis_kundi= lis_kunde;
		Connection conn = null;

		try {
			System.out.println("* Treiber laden");
			
		} catch (Exception e) {
			System.err.println("Treiber kann nicht geladen werden!!");
			e.printStackTrace();
		}
                 
                  
		try {
			System.out.println("* Verbindung aufbauen");
			String url = "jdbc:mysql://" + hostname + ":" + port + "/" + dbname;
			conn = DriverManager.getConnection(url, user, password);
			// ***** Verbindung
			System.out.println("* Statement beginnen");
			Statement stmt = (Statement) conn.createStatement();
			System.out.println("* Einfügen  beginnen");
			
			//Schleife zum Auslesen lis_kundi aus 
			 for (int z=0; z <lis_kundi.size();z++) {
			String sqlCommand = "Insert INTO ver_kundstamm (verk_kundnr, verk_name,"
					+ "verk_Vorname, verk_geburtstag,verk_timestamp)" + "VALUES(" + lis_kundi.get(z)  + "," 
					+  "'" + lis_kundi.get(++z) + "'"+ ","  + "'" + lis_kundi.get(++z)
					+ "'" + "," + "'" + lis_kundi.get(++z) + "'" + "," + "CURRENT_TIMESTAMP" + ")";
			System.out.println(sqlCommand);
			((java.sql.Statement) stmt).executeUpdate(sqlCommand); // da nur geschrieben wird
										              	// executeUpdate
			 } 
			// **beenden Eingabe
				System.out.println("* Statement beenden");
				//((Connection) stmt).close();
			      stmt.close();
		} catch (SQLException sqle) {
			System.out.println("SQLException: " + sqle.getMessage());
			System.out.println("SQLState: " + sqle.getSQLState());
			System.out.println("VendorError: " + sqle.getErrorCode());
			sqle.printStackTrace();
		}
		      
				
	}
  }
//}

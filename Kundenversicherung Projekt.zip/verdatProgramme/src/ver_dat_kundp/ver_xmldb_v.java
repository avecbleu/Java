package ver_dat_kundp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import interfacep.DB_zugriff;

/*
 *Aus  ver_xml_auslesen  ArrayList lis_versicherung übernehmen 
 */

public class ver_xmldb_v implements DB_zugriff {
	 ArrayList <String> lis_versi = new ArrayList <String>(); 
	 

	public ver_xmldb_v(ArrayList<String> lis_versicherung) {
		lis_versi= lis_versicherung;
		Connection conn = null;

		try {
			System.out.println("* Treiber laden");
			
		} catch (Exception e) {
			System.err.println("Treiber kann nicht geladen werden!!");
			e.printStackTrace();
		}
                 
                  
		try {
			System.out.println("* Verbindung aufbauen");
			String url = "jdbc:mysql://" + hostname + ":" + port + "/" + dbname;
			conn = DriverManager.getConnection(url, user, password);
			// ***** Verbindung
			System.out.println("* Statement beginnen");
			Statement stmt = (Statement) conn.createStatement();
			System.out.println("* Einfügen  beginnen");
			
			//Schleife zum Auslesen lis_kundi aus 
			 for (int z=0; z <lis_versi.size();z++) {
			String sqlCommand = "Insert INTO ver_versicherung (ver_V_Key,Ver_Nr, r_ver_art,"
					+ "r_ver_bez, r_v_beginn,r_v_ende,r_betrag, r_kdnr,r_timestamp)" + "VALUES( "+ "NULL" +"," + lis_versi.get(z)  + "," 
					+  "'" + lis_versi.get(++z) + "'"+ ","+  "'" + lis_versi.get(++z) + "'"+ ","  + "'" 
					+ lis_versi.get(++z)
					+ "'" + "," + "'" + lis_versi.get(++z) + "'" + "," + "'"
					+ lis_versi.get(++z) + "'" + ","  +lis_versi.get(++z) 
					+ "," + "CURRENT_TIMESTAMP" + ")";
			System.out.println(sqlCommand);
			((java.sql.Statement) stmt).executeUpdate(sqlCommand); // da nur geschrieben wird
										              	// executeUpdate
			 }  
			// **beenden Eingabe
				System.out.println("* Statement beenden");
				//((Connection) stmt).close();
			      stmt.close();
		} catch (SQLException sqle) {
			System.out.println("SQLException: " + sqle.getMessage());
			System.out.println("SQLState: " + sqle.getSQLState());
			System.out.println("VendorError: " + sqle.getErrorCode());
			sqle.printStackTrace();
		}
		      
				
	}
}



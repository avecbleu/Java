package ver_dbp;

import java.sql.Connection;

/*
 * Mit Datei kundeni.csv die Tabelle ver_kundstamm  erweitern
 * in Datenbank  ver_dat  
 * 9.3.2023
 */
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import interfacep.DB_zugriff;



public class ver_db_load implements DB_zugriff {
String kundennummer,name, vorname, g_dat;

	public ver_db_load(String pfada) {

		// Diese Eintraege werden zum
		// Verbindungsaufbau benoetigt.
		
		String path= pfada;
		


		Connection conn = null;

		try {
			System.out.println("* Treiber laden");
			// Class.forName("org.gjt.mm.mysql.Driver").newInstance();
		} catch (Exception e) {
			System.err.println("Treiber kann nicht geladen werden!!");
			e.printStackTrace();
		}

		try {
			System.out.println("* Verbindung aufbauen");
			String url = "jdbc:mysql://" + hostname + ":" + port + "/" + dbname;
			conn = DriverManager.getConnection(url, user, password);
			// ***** Verbindung
			System.out.println("* Statement beginnen");
			Statement stmt = (Statement) conn.createStatement();
			// *************hier SQL:Statments
			System.out.println("* Einfügen  beginnen");

			//String path1 = path.replace("\\","/"); 
			String path1 = path.replace('\\', '/'); 
             System.out.println(path1);
			//System.out.println(kundenr + "  " + name2);
			String sqlCommand = "LOAD DATA INFILE "+"'"+ path1 +"'"
					+ " INTO TABLE ver_kundstamm"
					+ " FIELDS TERMINATED BY ';'"
					+ " ENCLOSED BY ''"
					+ " LINES TERMINATED BY '\n' "
					+ "IGNORE 1 LINES " ;
					
			System.out.println(sqlCommand);
			stmt.executeUpdate(sqlCommand); // da nur geschrieben wird
											// executeUpdate

			// **beenden Eingabe
			System.out.println("* Statement beenden");
			stmt.close();
			
              
			

			
			System.out.println("* Datenbank-Verbindung beenden");
			
		} 
		catch (SQLException sqle) {
			System.out.println("SQLException: " + sqle.getMessage());
			System.out.println("SQLState: " + sqle.getSQLState());
			System.out.println("VendorError: " + sqle.getErrorCode());
			sqle.printStackTrace();
		}
		
		   // **********************Aufruf  Auswertung  Co_dbanzg.java
     
		

	}// Konstruktor ende
	
}
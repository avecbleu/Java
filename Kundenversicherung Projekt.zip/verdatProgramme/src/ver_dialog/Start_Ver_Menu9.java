package ver_dialog;

import java.awt.BorderLayout;
import java.io.FileNotFoundException;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

import ver_csvP.ver_csv_adressi2;
import ver_csvP.ver_csv_kundeni;
//import ver_csvP.ver_csv_adressi2;
//import ver_csvP.ver_csv_kundeni;
import ver_dat_kundp.Ver_anz_auswahls;
import ver_dat_kundp.Ver_anz_liste;
import ver_json.ver_json_datei_lesen;
import ver_xmlp.ver_xml_auslesen;
import ver_xmlp.ver_xml_auslesen2;

/*
 * Auswahl  ausw=1 = Ändern Kunde Update
 *          ausw=2 =  Eingabe Insert Versicherung 
 *          ausw= 3 = Eingabe Kundendaten 
 *          ausw =4  = Versicherung einfügen 
 *          ausw = 5 = Anzeige Kudendaten mit Versicherung   
 *         
 */

public class Start_Ver_Menu9 extends JFrame {
	 // Menüleiste 
	
    JMenuBar menuBar;
 
    // Menü "Datei"
    JMenu fileMenu;
    JMenu  fileueber;  // Änderung 
 
   
    JMenuItem openItem4;  // Anzeige Kunden 
    JMenuItem openItem5;  //  Eingabe Versicherung
    JMenuItem openItem3;  // Anzeige einzelne Kunden 
    JMenuItem openItem;  //Änderung Eingabe Kunden 
    JMenuItem openItem2;  //Update  Kunden 
    JMenuItem openItem6;  //Kundenanzeige mit Versicherung 
    JMenuItem closeItem;   
    JMenuItem ue_openItem1;  //Übernahme der Daten csv 
    JMenuItem ue_openItem2;  //Übernahme der Daten xml
    JMenuItem ue_openItem3;  //Übernahme der Daten json  
   // Boolean auswb= false; // Wenn update ausgewählt wird
   // Boolean vauswb= false; // Wenn Eingabe Versicherung
    
   
    int ausw=0;
    public Start_Ver_Menu9() {
        this.setTitle("JMenu mit ActionListener Test2");
        this.setSize(400, 300);
 
        // Menüleiste wird erzeugt
        menuBar = new JMenuBar();
 
        // Menü "Datei" wird erzeugt
        fileMenu = new JMenu("Kundenstamm");
        
      
       openItem4 = new JMenuItem("Anzeige Kunden mit Adresse");
       openItem3 = new JMenuItem("Anzeige Einzelkunden");  
       openItem = new JMenuItem("Eingabe Kunden");  
       openItem2 = new JMenuItem("Ändern Kunde "); 
       openItem5 = new JMenuItem("Eingabe Versicherung "); 
       openItem6 = new JMenuItem("Anzeige Kunden mit Versicherung ");  //Änderung
       closeItem = new JMenuItem("Schließen"); 
        fileMenu.add(openItem4);  // Anzeige Kunde mit Adresse
        fileMenu.add(openItem3); 
        fileMenu.add(openItem);  // Eingabe Einzelkunde  
        fileMenu.add(openItem2);  
        fileMenu.add(openItem5);  
        fileMenu.add(openItem6);  //Anz. Kunde mit Versicherung //Änderung
        fileMenu.add(closeItem); 
        
        //************Datenübernahme  //Änderung
        fileueber = new JMenu("Datenübernahme");
        ue_openItem1= new JMenuItem("Übernahme aus CSV-Dateien ");
        ue_openItem2= new JMenuItem("Übernahme aus XML-Dateien "); 
        ue_openItem3= new JMenuItem("Übernahme aus JSON-Dateien "); //Änderung
        fileueber.add(ue_openItem1); //Übernahme aus csv-Dateien 
        fileueber.add(ue_openItem2); //Übernahme aus xml-Dateien  
        fileueber.add(ue_openItem3); //Übernahme aus json-Dateien  //Änderung
        //Datei-Menü wird der Menüleiste hinzugefügt
        menuBar.add(fileMenu);
        menuBar.add(fileueber); //Änderung
 
        //Menüleiste wird dem JFrame hinzugefügt
        this.add(menuBar, BorderLayout.NORTH);
        
        //************ActionListener für openItem2 Ändern Kunde
        openItem2.addActionListener(new java.awt.event.ActionListener() {
            // Beim Drücken des Menüpunktes wird actionPerformed aufgerufen
            public void actionPerformed(java.awt.event.ActionEvent e2) {
                // Update Kundendaten 
            	
                  
            	 ausw=1;	
            	// auswb= true; // Wenn update ausgewählt wird
            	
            	
				Ver_anz_auswahls vaa = new Ver_anz_auswahls(ausw);
               
           }
        });
        
        //************ActionListener für openItem2 Eingabe Versicherung 
        openItem5.addActionListener(new java.awt.event.ActionListener() {
            // Beim Drücken des Menüpunktes wird actionPerformed aufgerufen
            public void actionPerformed(java.awt.event.ActionEvent e2) {
                // Eingabe Versicherung
            	
                  ausw=4;
            		
            	
            	 Ver_anz_auswahls vaa = new Ver_anz_auswahls(ausw);
               
           }
        });
        
        //************ActionListener für openItem6 Anzeige Kundendaten mit Versicherung 
        openItem6.addActionListener(new java.awt.event.ActionListener() {
            // Beim Drücken des Menüpunktes wird actionPerformed aufgerufen
            public void actionPerformed(java.awt.event.ActionEvent e2) {
                // Eingabe Versicherung
            	System.out.println("Punkt Anzeige Kunden mit Versicherung");
                  ausw=5;
            		
            	
            	 Ver_anz_auswahls vaa = new Ver_anz_auswahls(ausw);
               
           }
        });
        
      //************ActionListener für openItem Eingabe Kunden
        openItem.addActionListener(new java.awt.event.ActionListener() {
            // Beim Drücken des Menüpunktes wird actionPerformed aufgerufen
            public void actionPerformed(java.awt.event.ActionEvent e3) {
                // Eingabe Kundendaten 
           
                  
            		
                 Ver_kunde3 vk3 = new Ver_kunde3();
               
            }
        });
 
        
        //************ActionListener für openItem4 Anzeige Kunden
        openItem4.addActionListener(new java.awt.event.ActionListener() {
            // Beim Drücken des Menüpunktes wird actionPerformed aufgerufen
            public void actionPerformed(java.awt.event.ActionEvent e3) {
                // Eingabe Kundendaten 
           
                  
            		Ver_anz_liste val =new Ver_anz_liste();
            
               
            }
        });
        
        //************ActionListener für openItem3 Anzeige einzelne  Kunden
        openItem3.addActionListener(new java.awt.event.ActionListener() {
            // Beim Drücken des Menüpunktes wird actionPerformed aufgerufen
            public void actionPerformed(java.awt.event.ActionEvent e3) {
                // Anzeige Einzelkunden 
                  ausw=3;
                //  auswb=false;
            		
                     // Ver_anz_auswahls verau = new Ver_anz_auswahls(auswb,vauswb); // Auswahl Kunden
                      Ver_anz_auswahls verau = new Ver_anz_auswahls(ausw); // Auswahl Kunden
               
            }
        });
        
        // ***************Datenübernahmen
        //************ActionListener für ueopenItem1 Übernahme CSV-Datei 
        ue_openItem1.addActionListener(new java.awt.event.ActionListener() {
            // Beim Drücken des Menüpunktes wird actionPerformed aufgerufen
            public void actionPerformed(java.awt.event.ActionEvent e3) {
                // Übernahem CSV-Datei
           
                  
            		try {
						ver_csv_kundeni vcv =new ver_csv_kundeni(); //für Tabelle 
						                                            // ver_kundstamm
						Thread.sleep(1000); //1 Sekunde
						
						ver_csv_adressi2 vca =new ver_csv_adressi2(); //für Tabelle 
						                                            // ver_adresse
					} catch (InterruptedException | FileNotFoundException e) {
						
						e.printStackTrace();
					}
            
               
            }
        });
      //************ActionListener für ueopenItem2 Übernahme xml-Datei 
        ue_openItem2.addActionListener(new java.awt.event.ActionListener() {
            // Beim Drücken des Menüpunktes wird actionPerformed aufgerufen
            public void actionPerformed(java.awt.event.ActionEvent e4) {
                // Übernahem xml-Datei
           
                  
            		//ver_xml_auslesen vxa =new ver_xml_auslesen(); //für Tabellen 
            		ver_xml_auslesen2 vxa =new ver_xml_auslesen2(); //für Tabellen 
					                                            // ver_kundstamm
					                                            //ver_adresse
					                                            //ver_versicherung 

            
               
            }
        });
      //************ActionListener für ueopenItem3 Übernahme json-Datei 
        ue_openItem3.addActionListener(new java.awt.event.ActionListener() {
            // Beim Drücken des Menüpunktes wird actionPerformed aufgerufen
            public void actionPerformed(java.awt.event.ActionEvent e4) {
                // Übernahem json-Datei
          
                  
           ver_json_datei_lesen vjd = new ver_json_datei_lesen();// aus daten_verdat.json
                                                                 //für Tabellen 
                                                                  // ver_kundstamm
                                                              //ver_adresse
                                                           //ver_versicherung

            
               
            }
        });
        // ActionListener wird als anonyme Klasse eingebunden
        closeItem.addActionListener(new java.awt.event.ActionListener() {
            // Beim Drücken des Menüpunktes wird actionPerformed aufgerufen
            public void actionPerformed(java.awt.event.ActionEvent e) {
                //Programm schließen
                System.exit(0);
            }
        });
       
        
        setVisible(true);
    }
    public static void main(String[] args) {
		Start_Ver_Menu9 vmn = new Start_Ver_Menu9();

	}
    
}

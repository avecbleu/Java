package ver_dialog;

import static java.awt.GridBagConstraints.NORTH;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import ver_dat_kundp.Ver_Kund_adr_ausw;
import ver_dat_kundp.Ver_dat_adress_update2;
import ver_dat_kundp.Ver_dat_update;




public class Ver_kunde_update extends JFrame  implements ActionListener {
	//JTextField v_kundenr = new JTextField(10);
	JFormattedTextField v_kundenr = new JFormattedTextField();
	//JComboBox Kcombo = new JComboBox();
	JTextField v_name = new JTextField("",30);
	JTextField v_vorname = new JTextField("",30);
	JTextField v_geburtstag = new JTextField("",10);
	//Adresse eingeben 
	JTextField v_strasse = new JTextField("",30);
	JTextField v_hausnr = new JTextField("",10);
	JTextField v_plz = new JTextField("",15);
	JTextField v_ort = new JTextField("",30);
	JTextField v_lkz = new JTextField("",10);
	JTextField v_kdnr = new JTextField("",10);
	JButton knopf1 =new JButton(" ok");
	JButton knopf2 =new JButton(" Abbruch ");
	 Boolean fehler = true;
	 String kundenr;
	 Font font = new Font(Font.DIALOG, Font.PLAIN, 16); // Font setzen
	public Ver_kunde_update(String kundennummer, String name, String vorname,String gebdat, String strasse, String hausnr,
			                        String plz, String ort, String ort2){    //Konstruktuor
		
		
		setTitle("Dialog Kundenupdate Ver_kunde_update");
	
	
	// Das Programm soll  beendet werden.
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		GridBagLayout gbLayout= new GridBagLayout();
		GridBagConstraints gbCons = new GridBagConstraints();
		setLayout(gbLayout);
	 
	
	
	JLabel lkdnr = new JLabel("Kundenummer: ");
	JLabel lname =new JLabel("Name: ");
	JLabel lvname =new JLabel("Vorname");
	JLabel lgeb =new JLabel("Geburtstag JJJJ-MM-TT ");
	
	//Adresse 
	JLabel lstr = new JLabel("Straße: ");
	JLabel lhsr =new JLabel("Haus-Nr: ");
	JLabel lplz =new JLabel("Plz:");
	
	JLabel lort =new JLabel("Ort:");
	JLabel llkz =new JLabel("Länder-KZ:");
	// Festlegung horizontal oder vertikal 
    fuellen(kundennummer,name,vorname,gebdat,strasse,hausnr,plz,ort);
	
	
	
    //  Bedienelemente 
	//Kundennummer
    
     gbCons.anchor = NORTH;	
	 gbCons.fill = GridBagConstraints.HORIZONTAL;
	 gbCons.weightx = .2;
     gbCons.gridx =0;
     gbCons.gridy =0;
     gbCons.insets = new Insets(10, 0, 15, 0);// Abstand Zeilen top,left,bottom,right
	
	//**Label Ende
     //FONT setzen
     lkdnr.setFont(font);
	add(lkdnr,gbCons);
	//Kcombo.addActionListener(klist);
	
     gbCons.gridx =1;
    // gbCons.gridy =0;		 
   //FONT setzen
     v_kundenr.setFont(font);
     v_kundenr.setColumns(10);
	add(v_kundenr,gbCons);
	
	//********Kundennummer Ende
	
	//Name	
	gbCons.fill = GridBagConstraints.HORIZONTAL;
	gbCons.gridy =1;
	gbCons.gridx =0;
	//FONT setzen
    lname.setFont(font);
	add(lname,gbCons);
	//***Label Name Ende 
	
	gbCons.weightx = .4;
	gbCons.gridx =1;
	// Font setzen
	v_name=mfont(v_name);
	add(v_name,gbCons);
	//****Name Ende 
	//Vorname
	gbCons.gridy =3;
	gbCons.gridx =0;
	// Font setzen
	lvname=mfontl(lvname);
	add(lvname,gbCons);
	//**Label Vorname Ende
	gbCons.weightx = .4;
	gbCons.gridx =1;
	// Font setzen
		v_vorname=mfont(v_vorname);
	add(v_vorname,gbCons);
	//****** Vorname Ende
	//Geburtstag
	gbCons.gridy =4;
	gbCons.gridx =0;
	// Font setzen
		lgeb=mfontl(lgeb);
	add(lgeb,gbCons);
	//***Label Geburtstag Ende
	gbCons.weightx = .4;
	gbCons.gridx =1;
	// Font setzen
	v_geburtstag=mfont(v_geburtstag);
	add(v_geburtstag,gbCons);
	//****Geburtstag Ende
	 gbCons.insets = new Insets(30, 0, 15, 0);// Abstand Zeilen top,left,bottom,right
		
	//******Adresse eingeben
	//**Straße
	gbCons.weightx = .2;
    gbCons.gridx =0;
    gbCons.gridy =6;		 
 // Font setzen
 	lstr=mfontl(lstr);
	add(lstr,gbCons);
	gbCons.gridx =1;
	// Font setzen
	v_strasse=mfont(v_strasse);
	add(v_strasse,gbCons);
	//********Strasse Ende
		//Hausnummer 
	gbCons.weightx = .2;
    gbCons.gridx =2;
    gbCons.gridy =6;		 
 // Font setzen
 	lhsr=mfontl(lhsr);
	add(lhsr,gbCons);
		gbCons.weightx = .2;
		gbCons.gridx =3;
		gbCons.gridy =6;
		// Font setzen
		v_hausnr=mfont(v_hausnr);
		add(v_hausnr,gbCons);
		//****Hausnummer  Ende 
		 gbCons.insets = new Insets(10, 0, 15, 0);// Abstand Zeilen top,left,bottom,right
			
		//Postleitzahl 
		gbCons.gridy =7;
		gbCons.gridx =0;
		// Font setzen
		lplz=mfontl(lplz);
		add(lplz,gbCons);
		//**Label Postleitzahl Ende
		gbCons.weightx = .4;
		gbCons.gridx =1;
		// Font setzen
		v_plz=mfont(v_plz);
		add(v_plz,gbCons);
		//****** Postleitzahl  Ende
		//Ort
		gbCons.gridy =7;
		gbCons.gridx =2;
		// Font setzen
		lort=mfontl(lort);
		add(lort,gbCons);
		//gbCons.gridy =7;
		gbCons.gridx =3;
		// Font setzen
		v_ort=mfont(v_ort);
		add(v_ort,gbCons);
		//****Ort  Ende
		//LKZ
				gbCons.gridy =8;
				gbCons.gridx =0;
				// Font setzen
				llkz=mfontl(llkz);
				add(llkz,gbCons);
				//***Label LKZ Ende
				gbCons.weightx = .4;
				gbCons.gridx =1;
				// Font setzen
				v_lkz=mfont(v_lkz);
				add(v_lkz,gbCons);
				//****LKZ  Ende
	
	//Zuweisung Button 
	gbCons.fill = GridBagConstraints.VERTICAL;
	//gbCons.gridheight =2;
	//gbCons.weightx = 0.5;
	gbCons.gridy =20;
	gbCons.gridx =0;
	
	
	//********Button
	//panel.add(knopf1,gbCons);
	add(knopf1,gbCons);
	//gbCons.fill = GridBagConstraints.BOTH;
	gbCons.gridheight =2;
	gbCons.gridy =20;
	gbCons.gridx =1;
	//panel.add(knopf2,gbCons);
	add(knopf2,gbCons);
	//****Ende Knöpfe
	knopf1.addActionListener(this);
	knopf2.addActionListener(this);
	
	setSize(500, 500);
	
	//setLocationRelativeTo(null);
	
   // this.add(panel);
      pack();
		setVisible(true);
	}
	 // Font setzten  Label 
	private JLabel mfontl(JLabel label1) {
		label1.setFont(font);
		return label1;
	}

	//********Font setzen  TextFeld
       private JTextField mfont(JTextField feld) {
    	 //FONT setzen
    	     feld.setFont(font);
		return feld;
	}
	//Methode füllen
	private void fuellen(String kundennummer, String name, String vorname,String gebdat, 
			                      String strasse, String hausnr, String plz,
			String ort) {
		v_kundenr.setText(kundennummer);
		v_name.setText(name);
		v_vorname.setText(vorname);
		v_geburtstag.setText(gebdat);
		v_strasse.setText(strasse);
		v_hausnr.setText(hausnr);
		v_plz.setText(plz);
		v_ort.setText(ort);
	}

	

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource() == this.knopf1){  
           
           String kundenr = this.v_kundenr.getText();  //übernehmen Kundennr
           pruefi(kundenr);
          if(fehler) {
        	   
           
        	   
   		   String name  = this.v_name.getText();    //übernehmen Name
   		   String vorname  = this.v_vorname.getText();    //übernehmen Vorname
   		    String gebtag   = this.v_geburtstag.getText();    //übernehmen Geburtstag
   		  System.out.println("Knopf1 an "+ kundenr+ " wf "+ name);
   		//**********Leerzeichen entfernen 
   		  kundenr  = kundenr.trim(); 
   		  name  = name.trim();  
   		  vorname  = vorname.trim();
   		   gebtag  = gebtag.trim(); 
   		System.out.println("Knopf1 an "+ kundenr+ " wf "+ name);
   		
   		//**Adresse vorbereiten
   	 String strasse = this.v_strasse.getText();  //Übernehmen Stra�e
		   String hausnr  = this.v_hausnr.getText();    //Übernehmen Hausnummer
		   String plz  = this.v_plz.getText();    //Übernehmen PLZ
		   String ort   = this.v_ort.getText();    //ort
		   String lkz   = this.v_lkz.getText();   //LKZ 
   		  //meinJDialog.dispose();
   		   dispose();
   		   //Aufruf Programm    In ver_kundenstamm updaten 
   		Ver_dat_update vdu = new Ver_dat_update(kundenr, name, vorname,gebtag);
   	 //Aufruf Programm    In ver_adresse updaten 
   		Ver_dat_adress_update2 vdau = new Ver_dat_adress_update2(strasse,hausnr,plz,ort,lkz,kundenr);   
        }
		else if (e.getSource() == this.knopf2){
			System.out.println("Knopf2 an" );
			System.exit(0);
		}
	}     // if ende
	}

	private void pruefi(String kundenr) {
		String onlyRegex="[0-9]*";
		if(kundenr.matches(onlyRegex)) {
			System.out.println("richtig Nur Zahlen");
			fehler = true;
		}
		else {
			System.out.println("Bitte bei Kundenummer nur zahlen eingeben");
			//Ver_kunde verk = new Ver_kunde();
			fehler= false;
		}	
	}	
	
	//Action Listener  ComboBox
	//ActionListener klist = new ActionListener() { // Muss defieniert werden

		
	/*	public void actionPerformed(ActionEvent e) {  // wird angelegt 
			System.out.println("Selected: " + Kcombo.getSelectedItem());
	        System.out.println(", Position: " + Kcombo.getSelectedIndex());
			 kundenr=(String) Kcombo.getSelectedItem();
			 
			 
		}
    	// Boolean updb =true;  //Auswahl Update 
    	// Ver_Kund_adr_ausw vkaa = new Ver_Kund_adr_ausw(kundenr,updb);
     };
}*/
}



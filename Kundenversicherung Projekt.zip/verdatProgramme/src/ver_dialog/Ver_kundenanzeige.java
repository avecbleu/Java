package ver_dialog;

import java.awt.BorderLayout;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.ComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import ver_dat_kundp.Ver_Kund_adr_ausw;

/*Aufruf aus Ver_anz_auswahls
 * Aufruf  Kundenanzeige  Anzeige der ausgewählten Daten 
 * Nächstes Programm  Ver_Kund_adr_ausw mit Parameter Kundennummer ausw
 */


public class Ver_kundenanzeige extends JFrame  implements ActionListener {
	JTextField v_kundenr = new JTextField("",10);
	JTextField v_name = new JTextField("",50);
	JComboBox Kcombo = new JComboBox();
	JButton knopf1 =new JButton(" ok");
	JButton knopf2 =new JButton(" Abbruch ");
	String kundenr;
	//Boolean ausw;
	//Boolean verausw;
	int ausw2=0;
	//JDialog meinJDialog = new JDialog();
	ArrayList<String> kliste = new ArrayList<String>(); 
	public Ver_kundenanzeige(ArrayList<String> liste2,  int ausw) {    //Konstruktuor
		ausw2=ausw;
		//verausw=  auswb;  // Versicherung Auswahl 
	kliste=liste2;
	// Umsetzen Arraylist in ComboBox
		Kcombo = new JComboBox(kliste.toArray());
		setTitle("Dialog Kundeneingabe ver_kundenanzeige");
	
	//setLayout(new BorderLayout());  //BorderLayout setzen
	// Das Programm soll  beendet werden.
	setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		GridBagLayout gbLayout= new GridBagLayout();
		GridBagConstraints gbCons = new GridBagConstraints();
	
	 // Hinzufügen  Komponenten, 
	JPanel panel = new JPanel();
	panel.setLayout(gbLayout);
	JLabel lkdnr = new JLabel("Kundenummer: ");
	JLabel lname =new JLabel("Name: ");
	
	// Festlegung horizontal oder vertikal 
    
	
	
	
    //  Bedienelemente panel  zuweisen 
	//Kundennummer
	 gbCons.fill = GridBagConstraints.HORIZONTAL;
	 gbCons.weightx = .2;
     gbCons.gridx =0;
     gbCons.gridy =0;		 
	panel.add(lkdnr,gbCons);
	//**Label Ende
	
     gbCons.gridx =1;
     
     	Kcombo.addActionListener(klist);
	panel.add(Kcombo,gbCons);
	//********Kundennummer Ende
	
	//Name	
	gbCons.gridy =1;
	gbCons.gridx =0;
	panel.add(lname,gbCons);
	//***Label Name Ende 
	
	gbCons.weightx = .4;
	gbCons.gridx =1;
	panel.add(this.v_name,gbCons);
	//****Name Ende 
	
	//Zuweisung Button 
	gbCons.fill = GridBagConstraints.VERTICAL;
	//gbCons.gridheight =2;
	//gbCons.weightx = 0.5;
	gbCons.gridy =8;
	gbCons.gridx =0;
	//gbCons.ipadx = 20; 
	panel.add(knopf1,gbCons);
	//gbCons.fill = GridBagConstraints.BOTH;
	gbCons.gridheight =2;
	gbCons.gridy =8;
	gbCons.gridx =1;
	panel.add(knopf2,gbCons);
	//****Ende Knöpfe
	knopf1.addActionListener(this);
	knopf2.addActionListener(this);
	
	setSize(500, 300);
	//pack();
	
    this.add(panel);
    
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource() == this.knopf1){  
           
        //   String kundenr = ;  //übernehmen Kundennr
   		   String name  = this.v_name.getText();    //übernehmen Name
   		  
   		 
   		  name  = name.trim();  
   		 
   		
   		   dispose();
   		   //Aufruf Programm    Kundenanzeige 
   		
   		Ver_Kund_adr_ausw  vka = new Ver_Kund_adr_ausw(kundenr,ausw2);
        }
		else if (e.getSource() == this.knopf2){
			System.out.println("Knopf2 an" );
			System.exit(0);
		}
	}
	
	//Action Listener 
	ActionListener klist = new ActionListener() { // Muss definiert werden

		
		public void actionPerformed(ActionEvent e) {  // wird angelegt 
			System.out.println("Selected: " + Kcombo.getSelectedItem());
	        System.out.println(", Position: " + Kcombo.getSelectedIndex());
			 kundenr=(String) Kcombo.getSelectedItem();
		}
    	 
     };
}



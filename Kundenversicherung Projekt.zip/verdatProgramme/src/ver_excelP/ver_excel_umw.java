package ver_excelP;

import java.io.FileInputStream;
import java.io.IOException;
//import java.text.DateFormat;
//import java.text.ParseException;
//import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
//import java.util.Calendar;
import java.util.Date;
//import java.util.GregorianCalendar;
import java.util.Iterator;
//import java.util.List;

//import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import ver_dat_kundp.ver_xmldb_adr;
import ver_dat_kundp.ver_xmldb_ku;
import ver_dat_kundp.ver_xmldb_v;

 
public class ver_excel_umw
{
   // static Date dat1=null;
   //static Date datum = new Date();
   // static Date datver= null;
    
    static ArrayList <String> lis_kunde = new ArrayList <String>();  
    static   ArrayList <String> lis_adresse = new ArrayList <String>();  
    static   ArrayList <String> lis_versicherung = new ArrayList <String>();  
    static String  fileName="";
   
		
	

   //  public ver_excel_umw(String fileName) { für unabhängingen Test Zeile 222
    	 public ver_excel_umw() {
    	 fileName = "D:\\Schulung\\Excel\\Ver_dat\\daten_verdat.xlsx";
        try {
            //Input File  von Excel Datei erstellen 
            FileInputStream fis = new FileInputStream(fileName);
            
            //Erstellllen einer Workbook instance von xlsx/xls FileInputStream
            Workbook workbook = null;
            // Abfragen auf Endung xlsx oder xls
            if(fileName.toLowerCase().endsWith("xlsx")){
                // Neues wokrbook  mit Endung xlsx
                workbook = new XSSFWorkbook(fis); 
            }else if(fileName.toLowerCase().endsWith("xls")){
             // Neues wokrbook  mit Endung xls
                workbook = new HSSFWorkbook(fis);
            }
            //Nummer der Tabellenblätter in  xlsx Datei
            int blattnummer = workbook.getNumberOfSheets();
          //*********Schleife für alle Tabellenblätter
            for(int i=0; i < blattnummer; i++){
                i= 0;        // Blatt -auswahl  erstes Blat
                //Hole das aktuelle Blatt von  workboot
                Sheet blatt = (Sheet)workbook.getSheetAt(i); 
                //*****************Zeile bearbeiten 
              //Jedes Blatt hat Zeilen, die wiedeholt werden 
                Iterator<Row> rowIterator = blatt.iterator();
                 
                while (rowIterator.hasNext()) 
                {
                   
             //      LocalDateTime bdatum=  null ;        // Berichtsdatum,
                 //  String datums="";
                 //  double datumb=0.0;
           //         String header="";
                    int kdnr= 0;        // Kundennummer
                    String nachn = "";             // Nachname
                    String vorna="";          // Vorname
                    String geb_dat="";              // Geb-Datum
                    LocalDateTime geb_datl=null;
                    String strasse ="";                 // Straße
                    String hausnr ="" ;               // Haus-Nr
                    int plz = 0;
                    String ort="";
                    String land ="";
                    int vernr=0;                //Versicherungsnummer
                    String ver_art="";
                    String ver_bez = null;
                    //String ver_beginn="";  // Datum Versicherungsbeginn
                    LocalDateTime ver_beginn=null;  // Datum Versicherungsbeginn
                    LocalDateTime ver_ende=null;    // Datum Versicherungsende
                    double ver_betrag = 0;
                    
                    
                    		
                    //hole das row Objekt
                    Row row = (Row)rowIterator.next();
                     int z =  row.getRowNum(); 
                     int z2 = row.getPhysicalNumberOfCells();
                   
                     
                       //************  Spalten bearbeiten
                    //Jede Zeile hat Spalten  hole die Spalten und wiederhole dieses
                    Iterator<Cell> spaltenZaehler = row.cellIterator();
                    while (spaltenZaehler.hasNext()) { 
                        //Hole das Spalten Objekt
                       
                        Cell cell = spaltenZaehler.next();  
                        int spalte = cell.getColumnIndex();   // Spaltenindex 
                       
                        int zeile = cell.getRowIndex();   // Zeilenindex
                        CellType test = cell.getCellType();
                        //Überprüfe die Spaltentyp und handel entsprechende
                       
                         //Nummerische Daten 
                          int z1= row.getRowNum() ; 
                       if (zeile >= 1 && spalte >= 0 ) {
                           
							switch (spalte) {
							case 0:	kdnr = (int) cell.getNumericCellValue(); break; // Berichtsdatum
							case 1:  nachn = cell.getStringCellValue();	break; // 
							case 2: vorna = cell.getStringCellValue();	break; // 
							case 3:geb_datl = cell.getLocalDateTimeCellValue();	break; // 
							case 4:strasse	 = cell.getStringCellValue(); break; // 
							case 5:hausnr = cell.getStringCellValue(); break; // 
							case 6:plz =  (int) cell.getNumericCellValue(); break; 
							case 7:	ort = cell.getStringCellValue(); break; 
							case 8:	land = cell.getStringCellValue(); break; 
							case 9:	vernr = (int) cell.getNumericCellValue(); break; 
							case 10: ver_art = cell.getStringCellValue(); break; 
							case 11: ver_bez = cell.getStringCellValue(); break; 
							case 12: ver_beginn = cell.getLocalDateTimeCellValue(); break; 
							case 13: ver_ende = cell.getLocalDateTimeCellValue(); break; 
							case 14: ver_betrag = cell.getNumericCellValue(); break; 
							default:
								break;

							}
                            
                          
                           if(spalte == 14 ) {  // erst dann alles vollständig
                        	   System.out.println("Satz anzeigen:  "+ " Kundnr "+ kdnr
                                       +" Nachname "+ nachn + "Vorname" + vorna +" "
                                       + "Geb_dat" + geb_datl + " Strasse "+ strasse+ "  Verbeginn "
                                       +  ver_beginn + " Vers-Betrag "+ ver_betrag);
                        
                             //*****Füllen ArraList für ver_dat
                            fuellen_kunde(kdnr,nachn,vorna,geb_datl);
                            fuellen_adresse(strasse,hausnr,plz,ort,land,kdnr);
                            fuellen_versich(vernr,ver_art,ver_bez,ver_beginn,ver_ende,ver_betrag,kdnr);
                            
                      
                         
                  }   // while 142    // immer die gleiche Zeile
                } // Ende 112 zeile 2
                    } //Ende Spalten Zähler z87
                   
                   } //Ende  while z 64 hasNext
                
                 } // for Blatt
            
                 fis.close();   // InputFile schließen
                 
              // Aufruf der Insert -Dateien 
    			 ver_xmldb_ku vxi = new ver_xmldb_ku(lis_kunde); //Insert ver_kundstamm
    		     ver_xmldb_adr vxa = new ver_xmldb_adr(lis_adresse); //Insert ver_adresse
    		     ver_xmldb_v vxv = new ver_xmldb_v(lis_versicherung); //Insert ver_versicherung
                 
                 
            }  catch (IOException e) {
                e.printStackTrace();
            }
              
    }
     //************Füllen  ver_sicherung 
     private static void fuellen_versich(int vernr, String ver_art, String ver_bez,
    		                           LocalDateTime ver_beginn,LocalDateTime ver_ende,
    		                           double ver_betrag, int kdnr) {
	lis_versicherung.add(String.valueOf(vernr));
	lis_versicherung.add(ver_art);
	lis_versicherung.add(ver_bez);
	String datb= String.valueOf(ver_beginn);
	datb= datb.substring(0,10); //Nur Datum übertragen 1995-05-06[TE00:00] []abgeschnitten
	lis_versicherung.add(datb);  
	String daten= String.valueOf(ver_ende);
	daten= daten.substring(0,10);  //Zeit abschneiden 
	lis_versicherung.add(daten);
	String betrag1= String.valueOf(ver_betrag).replace("," ,".");
	lis_versicherung.add(betrag1);
	lis_versicherung.add(String.valueOf(kdnr));
}

	//***********Füllen ver_adresse 
     private static void fuellen_adresse(String strasse, String hausnr, int plz, String ort, String land, int kdnr) {
    	 lis_adresse.add(strasse);
    	 lis_adresse.add(hausnr);
    	 lis_adresse.add(String.valueOf(plz));
    	 lis_adresse.add(ort);
    	 lis_adresse.add(land);
    	 lis_adresse.add(String.valueOf(kdnr));
}

	//Kundenstamm füllen 
     private static void fuellen_kunde(int kdnr, String nachn, String vorna, LocalDateTime geb_datl) {
	   lis_kunde.add(String.valueOf(kdnr));
	   lis_kunde.add(nachn);
	   lis_kunde.add(vorna);
	   String dat5= String.valueOf(geb_datl);
	   dat5= dat5.substring(0,10);
	   lis_kunde.add(dat5);
	   
}

	

 

   
 /*   public static <verdaten> void main(String[] args)
    {
    	fileName = "D:\\Schulung\\Excel\\Ver_dat\\daten_verdat.xlsx";
    	
    	new ver_excel_umw(fileName);
       
    }*/

}

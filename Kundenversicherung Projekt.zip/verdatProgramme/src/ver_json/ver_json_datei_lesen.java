package ver_json;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;

import ver_dat_kundp.ver_xmldb_adr;
import ver_dat_kundp.ver_xmldb_ku;
import ver_dat_kundp.ver_xmldb_v;


public class ver_json_datei_lesen {
	 
	 static String jsonString = "";
     String jarray ="";
     static JSONArray jarr= null;  
     static String[] kund = null;
     
     static ArrayList <String> lis_kunde = new ArrayList <String>();  
     static   ArrayList <String> lis_adresse = new ArrayList <String>();  
     static   ArrayList <String> lis_versicherung = new ArrayList <String>();  
		
	
     public ver_json_datei_lesen() {
		  
		  File f = new File("D:\\Schulung\\Json\\Verdat\\daten_verdat.json");
		 
		  System.out.println(f); 
		  //JSONArray jarr = jobj.getJSONArray("Kunden"); // Array erstellen 
		  String zeile = "";
         
         
		  try {
	            BufferedReader reader = new BufferedReader(new FileReader(f));
		    	  
	            
	            while ((zeile = reader.readLine()) != null) {
	                jsonString += zeile;
	            	if(zeile.equals("}")){
	                 System.out.println(jsonString);
	                 
	            	}
	            	
	            
	        
	    }
	            reader.close();
		  }            
	            catch (IOException e) {
	  	          e.printStackTrace();
	  	         }  
		  
		  //JSON Array lesen 
		  JSONObject jobj = new JSONObject(jsonString);   //1.
		  
          jarr = jobj.getJSONArray("Kunden"); //2. Array erstellen
          //** Schleife wichtig getJSONObject 
          for (int i=0; i< jarr.length();++i) {  //3.
             JSONObject rec =jarr.getJSONObject(i); //4.  Wichtig um auf die Elemente 
                                                  //zugreifen zu können
         
          //System.out.println("rec "+ rec);
           int kdnr = rec.getInt("Kundennummer");
           String name = rec.getString("Nachname");
            fuellen(rec,jarr);
           System.out.println("Kundennummer "+ kdnr+ " Name "+name);
          } // for ende
             System.out.println(lis_kunde+ " ENDE");
			 System.out.println(lis_adresse+ " Ende ");
			 System.out.println(lis_versicherung+ " Ende");
          
         // Aufruf der Insert -Dateien 
			 ver_xmldb_ku vxi = new ver_xmldb_ku(lis_kunde); //Insert ver_kundstamm
		       ver_xmldb_adr vxa = new ver_xmldb_adr(lis_adresse); //Insert ver_adresse
		       ver_xmldb_v vxv = new ver_xmldb_v(lis_versicherung); //Insert ver_versicherung
          
      	
         
        
 }
          //Füllen der Felder
	private static void fuellen(JSONObject rec, JSONArray jarr2) {
		//for (int i=0; i<rec.length();i++) {
		// für Kundenstamm  ver_kundstamm
		String kdnr="";
		  kdnr= String.valueOf(rec.getInt("Kundennummer"));
		 lis_kunde.add(String.valueOf(rec.getInt("Kundennummer")));
		 lis_kunde.add(rec.getString("Nachname"));
		 lis_kunde.add(rec.getString("Vorname"));
		 lis_kunde.add(rec.getString("Geb-Dat"));
		 //Adresse ver_adresse
		 lis_adresse.add(rec.getString("Strasse"));
		 lis_adresse.add(rec.getString("Haus-Nr"));
		 lis_adresse.add(rec.getString("Plz"));
		 lis_adresse.add(rec.getString("Ort"));
		 lis_adresse.add(rec.getString("Land"));
		 lis_adresse.add(kdnr);
	 // }	//For ende
		 
		 // Versicherung lis_versicherung
		 lis_versicherung.add(String.valueOf(rec.getInt("Vernr")));
		 lis_versicherung.add(rec.getString("Verart"));
		 lis_versicherung.add(rec.getString("Ver_bez"));
		 lis_versicherung.add(rec.getString("Ver_beginn"));
		 lis_versicherung.add(rec.getString("Ver_ende"));
		 lis_versicherung.add(String.valueOf(rec.getDouble("Ver_betrag")));
		 lis_versicherung.add(kdnr);
	}

	/*private static JSONArray listNumberArray(int max) {
		JSONArray res = new JSONArray();
		for (int i=0; i<max;i++) {
			//The value of the labels must be an String in order to make it work
			res.put(String.valueOf(i));
		}
		return res;
		
	}*/
}

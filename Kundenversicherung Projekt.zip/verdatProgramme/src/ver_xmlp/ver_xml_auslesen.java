package ver_xmlp;

/* Hier Auslesen der XML-Datei ver_datenxm 
 * Aufruf  ab Menü8
 * Hier nur Auslesen der Datei  ver_datenxml.xlm
 * Für beide Dateien ver_datenxml.xlm und ver_daten_nurVers.xml
 * ver_xml_auslesen2  verwenden 
 */
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.jdom2.Content;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;

import ver_dat_kundp.ver_xmldb_adr;
import ver_dat_kundp.ver_xmldb_ku;
import ver_dat_kundp.ver_xmldb_v;



public class ver_xml_auslesen
{
    private static final ArrayList<Double> String=null;
    
    static String kundenr="";
     
   static ArrayList <String> lis_kunde = new ArrayList <String>();  
   static   ArrayList <String> lis_adresse = new ArrayList <String>();  
   static   ArrayList <String> lis_versicherung = new ArrayList <String>();  
     
    

	public ver_xml_auslesen()
{
      
	  
	   // File f = new File();
      File f = new File("D:\\Schulung\\XML\\ver_dat\\ver_datenxml.xml");
       
     
        System.out.println(f);      
        try {
			Document doc = new SAXBuilder().build(f);
			Element pro = doc.getRootElement();  //SData
			System.out.println("Wurzelelement "+ pro);
			String  weelement="";
		
			 ///****Element daten auslesen
			
			 // Kaskadierung 
			 List<Element> allekunden  = pro.getChildren("kunde");
			
			 int zaehler = allekunden.size();  // Zähler definiren 
			 System.out.println("zaehler "+ zaehler);
		 for (int i=0; i<allekunden.size();i++) {
			 //Kunde
			 if (weelement.equals("kunde")){
			  //lis_kunde.add(kunde.getChildText("Kundennummer"));
			  lis_kunde.add(((Element) allekunden.get(i)).getChildText("Kundennummer"));
			  kundenr=((Element) allekunden.get(i)).getChildText("Kundennummer");
			  lis_kunde.add(((Element) allekunden.get(i)).getChildText("Nachname"));
			  lis_kunde.add(((Element) allekunden.get(i)).getChildText("Vorname"));
			  lis_kunde.add(((Element) allekunden.get(i)).getChildText("Geb-Dat"));
			 }
			 
			 //Adresse
			 lis_adresse.add(((Element) allekunden.get(i)).getChildText("Strasse"));
			 lis_adresse.add(((Element) allekunden.get(i)).getChildText("Haus-Nr"));
			 lis_adresse.add(((Element) allekunden.get(i)).getChildText("Plz"));
			 lis_adresse.add(((Element) allekunden.get(i)).getChildText("Ort"));
			 lis_adresse.add(((Element) allekunden.get(i)).getChildText("Land"));
			 lis_adresse.add(kundenr);
			 //Versicherung 
			 lis_versicherung.add(((Element) allekunden.get(i)).getChildText("Vernr"));
			 lis_versicherung.add(((Element) allekunden.get(i)).getChildText("Verart"));
			 lis_versicherung.add(((Element) allekunden.get(i)).getChildText("Ver_bez"));
			 lis_versicherung.add(((Element) allekunden.get(i)).getChildText("Ver_beginn"));
			 lis_versicherung.add(((Element) allekunden.get(i)).getChildText("Ver_ende"));
			 lis_versicherung.add(((Element) allekunden.get(i)).getChildText("Ver_betrag").replace(",", "."));
			 lis_versicherung.add(kundenr);
		}  //For ende 
			 System.out.println(lis_kunde+ " ENDE");
			 System.out.println(lis_adresse+ " Ende ");
			 System.out.println(lis_versicherung+ " Ende");
			 
			
			    
		
			
		
			
		
		     
		} catch (JDOMException e) {
			
			e.getMessage();
			e.printStackTrace();
		} catch (IOException e) {
			
			e.getMessage();
			System.out.println("Message "+e.getMessage());
		}
          
        ver_xmldb_ku vxi = new ver_xmldb_ku(lis_kunde); //Insert ver_kundstamm
        ver_xmldb_adr vxa = new ver_xmldb_adr(lis_adresse); //Insert ver_adresse
        ver_xmldb_v vxv = new ver_xmldb_v(lis_versicherung); //Insert ver_versicherung
        
}
}
	
/* public static void main(String[] args)
	    {
		 ver_xml_auslesen vxa = new ver_xml_auslesen();  //direkter AuFruf
	  
} */




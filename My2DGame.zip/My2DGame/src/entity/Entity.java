package entity;

public class Entity {

	 public int x, y;
	 public int speed;
	
}
